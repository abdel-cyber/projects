import tkinter as tk
from tkinter import messagebox, scrolledtext
from core_vm_logic import VCenterManager, DeploymentManager
import json

class VMDeployerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("VM Deployer GUI")
        self.root.geometry("700x600")
        self.config = {}

        self.create_widgets()

    def create_widgets(self):
        frame = tk.Frame(self.root)
        frame.pack(pady=10)

        tk.Label(frame, text="vCenter IP:").grid(row=0, column=0)
        self.vcenter_ip = tk.Entry(frame, width=30)
        self.vcenter_ip.grid(row=0, column=1)

        tk.Label(frame, text="Username:").grid(row=1, column=0)
        self.username = tk.Entry(frame, width=30)
        self.username.grid(row=1, column=1)

        tk.Label(frame, text="Password:").grid(row=2, column=0)
        self.password = tk.Entry(frame, show="*", width=30)
        self.password.grid(row=2, column=1)

        tk.Button(frame, text="Connect", command=self.connect_to_vcenter).grid(row=3, column=0, columnspan=2, pady=5)

        self.vm_frame = tk.LabelFrame(self.root, text="VM Configuration")
        self.vm_frame.pack(padx=10, pady=10, fill="x")

        self.vm_fields = {}
        labels = ["Name", "Template", "CPU", "RAM", "IP", "Gateway", "Subnet Mask", "DNS (comma separated)", "Hostname", "Admin Password", "Datastore", "Cluster", "VLAN"]
        for idx, label in enumerate(labels):
            tk.Label(self.vm_frame, text=label+":").grid(row=idx, column=0, sticky="w")
            entry = tk.Entry(self.vm_frame, width=40)
            entry.grid(row=idx, column=1)
            self.vm_fields[label] = entry

        tk.Button(self.root, text="Deploy VM", command=self.deploy_vm).pack(pady=10)

        self.log_area = scrolledtext.ScrolledText(self.root, height=10)
        self.log_area.pack(fill="both", expand=True, padx=10)

    def connect_to_vcenter(self):
        self.log("Connecting to vCenter...")
        server = self.vcenter_ip.get()
        user = self.username.get()
        pwd = self.password.get()
        try:
            self.vcenter = VCenterManager(server, user, pwd)
            self.log("✅ Connected to vCenter!")
        except Exception as e:
            self.log(f"❌ Failed to connect: {e}")
            messagebox.showerror("Connection Error", str(e))

    def deploy_vm(self):
        self.log("Preparing configuration...")
        vm_data = {label: entry.get() for label, entry in self.vm_fields.items()}
        try:
            self.config = {
                "vcenter": {
                    "server": self.vcenter_ip.get(),
                    "username": self.username.get(),
                    "password": self.password.get()
                },
                "vm": {
                    "name": vm_data["Name"],
                    "template": vm_data["Template"],
                    "cpu": int(vm_data["CPU"]),
                    "ram": int(vm_data["RAM"]),
                    "ip": vm_data["IP"],
                    "gateway": vm_data["Gateway"],
                    "subnet_mask": vm_data["Subnet Mask"],
                    "dns": [dns.strip() for dns in vm_data["DNS (comma separated)"].split(",")],
                    "hostname": vm_data["Hostname"],
                    "admin_password": vm_data["Admin Password"],
                    "datastore": vm_data["Datastore"],
                    "cluster": vm_data["Cluster"],
                    "vlan": vm_data["VLAN"]
                }
            }
            with open("config.json", "w") as f:
                json.dump(self.config, f, indent=2)

            deployer = DeploymentManager(self.vcenter, self.config["vm"], self.log)
            deployer.deploy()
        except Exception as e:
            self.log(f"❌ Deployment failed: {e}")
            messagebox.showerror("Deployment Error", str(e))

    def log(self, message):
        self.log_area.insert(tk.END, message + "\n")
        self.log_area.see(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = VMDeployerGUI(root)
    root.mainloop()