# VM Deployer GUI

## Prérequis

- Python 3.7+
- `tkinter` (inclus dans Python)
- `pyvmomi` (optionnel pour version complète)

## Lancer

```bash
python vm_deployer_gui.py
```

## Fonctionnalités

- Connexion vCenter
- Configuration VM complète (IP, RAM, CPU, etc.)
- Interface utilisateur graphique avec logs
- Création automatique du `config.json`
- Simulation du déploiement (vous pouvez remplacer par des appels pyvmomi réels)

## TODO

- Intégration réelle avec vCenter (pyvmomi)
- Vérifications dynamiques des ressources (template, cluster...)