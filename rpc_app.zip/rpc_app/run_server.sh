#!/bin/bash

cd "$(dirname "$0")"
java -cp bin com.passwordmanager.server.RPCServer
