package com.passwordmanager.client;

import com.passwordmanager.client.gui.ClientGUI;
import javax.swing.*;

public class RPCClient {
    public static void main(String[] args) {
        // Parse command line arguments
        final String host = args.length > 0 ? args[0] : "localhost";
        
        int port = 1099; // Default port
        if (args.length > 1) {
            try {
                port = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                System.err.println("Invalid port number, using default: 1099");
            }
        }
        
        final int finalPort = port;
        
        // Start GUI
        SwingUtilities.invokeLater(() -> {
            try {
                // Set look and feel
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("Failed to set look and feel: " + e.getMessage());
                // Proceed with default look and feel
            }
            
            try {
                // Create and show client GUI directly
                ClientGUI clientGUI = new ClientGUI(host, finalPort);
                clientGUI.setVisible(true);
                System.out.println("Client GUI started successfully");
            } catch (Exception e) {
                e.printStackTrace();
                System.err.println("Error launching GUI: " + e.getMessage());
                JOptionPane.showMessageDialog(null, 
                    "Error launching client: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
