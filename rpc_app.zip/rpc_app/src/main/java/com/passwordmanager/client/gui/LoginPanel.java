package com.passwordmanager.client.gui;

import com.passwordmanager.common.PasswordServiceRPC;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.regex.Pattern;

public class LoginPanel extends JPanel {
    public interface LoginListener {
        void loginSuccessful(String username);
    }
    
    // Validation patterns
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]{3,20}$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^.{6,}$");
    
    private final PasswordServiceRPC service;
    private final LoginListener parent;
    
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private final JButton loginButton;
    private final JButton registerButton;
    private final JLabel statusLabel;

    public LoginPanel(PasswordServiceRPC service, LoginListener parent) {
        this.service = service;
        this.parent = parent;
        
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(40, 40, 40, 40));
        
        // Title panel with icon
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("Password Manager");
        titleLabel.setFont(new Font(titleLabel.getFont().getName(), Font.BOLD, 28));
        titlePanel.add(titleLabel);
        
        // Create form panel with modern styling
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Username field
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font(usernameLabel.getFont().getName(), Font.PLAIN, 16));
        formPanel.add(usernameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        usernameField = new JTextField(15);
        usernameField.setToolTipText("3-20 characters, letters, numbers and underscores only");
        usernameField.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        usernameField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(usernameField, gbc);
        
        // Password field
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font(passwordLabel.getFont().getName(), Font.PLAIN, 16));
        formPanel.add(passwordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        passwordField = new JPasswordField(15);
        passwordField.setToolTipText("Minimum 6 characters");
        passwordField.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        passwordField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(passwordField, gbc);
        
        // Status label for validation messages
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        statusLabel = new JLabel(" ");
        statusLabel.setForeground(Color.RED);
        statusLabel.setFont(new Font(statusLabel.getFont().getName(), Font.PLAIN, 14));
        statusLabel.setHorizontalAlignment(JLabel.CENTER);
        formPanel.add(statusLabel, gbc);
        
        // Button panel with modern styling
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");
        
        // Style buttons
        loginButton.setPreferredSize(new Dimension(150, 40));
        registerButton.setPreferredSize(new Dimension(150, 40));
        loginButton.setFont(new Font(loginButton.getFont().getName(), Font.BOLD, 16));
        registerButton.setFont(new Font(registerButton.getFont().getName(), Font.BOLD, 16));
        loginButton.setFocusPainted(false);
        registerButton.setFocusPainted(false);
        
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        
        // Add panels to layout
        add(titlePanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Add action listeners
        loginButton.addActionListener(this::onLogin);
        registerButton.addActionListener(this::onRegister);
        
        // Add enter key action
        passwordField.addActionListener(this::onLogin);
    }
    
    private void onLogin(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        // Client-side validation
        if (!validateCredentials(username, password)) {
            return;
        }
        
        // Attempt login
        try {
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            if (service.login(username, password)) {
                statusLabel.setText("");
                parent.loginSuccessful(username);
            } else {
                statusLabel.setText("Invalid username or password");
                passwordField.setText("");
            }
        } catch (Exception ex) {
            statusLabel.setText("Error: " + ex.getMessage());
        } finally {
            setCursor(Cursor.getDefaultCursor());
        }
    }
    
    private void onRegister(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        // Client-side validation
        if (!validateCredentials(username, password)) {
            return;
        }
        
        // Attempt registration
        try {
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            if (service.register(username, password)) {
                JOptionPane.showMessageDialog(this, 
                    "Registration successful! You can now login.",
                    "Registration Complete", JOptionPane.INFORMATION_MESSAGE);
                statusLabel.setText("");
            } else {
                statusLabel.setText("Username already exists");
            }
        } catch (Exception ex) {
            statusLabel.setText("Error: " + ex.getMessage());
        } finally {
            setCursor(Cursor.getDefaultCursor());
        }
    }
    
    private boolean validateCredentials(String username, String password) {
        if (username.isEmpty()) {
            statusLabel.setText("Username cannot be empty");
            usernameField.requestFocus();
            return false;
        }
        
        if (!USERNAME_PATTERN.matcher(username).matches()) {
            statusLabel.setText("Username must be 3-20 characters (letters, numbers, underscores)");
            usernameField.requestFocus();
            return false;
        }
        
        if (password.isEmpty()) {
            statusLabel.setText("Password cannot be empty");
            passwordField.requestFocus();
            return false;
        }
        
        if (!PASSWORD_PATTERN.matcher(password).matches()) {
            statusLabel.setText("Password must be at least 6 characters");
            passwordField.setText("");
            passwordField.requestFocus();
            return false;
        }
        
        return true;
    }
}
