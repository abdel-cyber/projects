package com.passwordmanager.client;

import com.passwordmanager.common.PasswordServiceRPC;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Map;

public class PasswordServiceRPCProxy implements PasswordServiceRPC {
    private static final long serialVersionUID = 1L;
    private final String host;
    private final int port;
    private transient Socket socket;
    private transient ObjectOutputStream out;
    private transient ObjectInputStream in;
    
    public PasswordServiceRPCProxy(String host, int port) {
        this.host = host;
        this.port = port;
        connect();
    }
    
    private void connect() {
        try {
            if (socket == null || socket.isClosed()) {
                socket = new Socket(host, port);
                out = new ObjectOutputStream(socket.getOutputStream());
                in = new ObjectInputStream(socket.getInputStream());
            }
        } catch (Exception e) {
            throw new RuntimeException("Connection failed: " + e.getMessage(), e);
        }
    }
    
    private Object invoke(String methodName, Object... params) {
        try {
            connect(); // Ensure connection
            out.writeObject(methodName);
            out.writeObject(params);
            out.flush();
            
            Object result = in.readObject();
            if (result instanceof Exception) {
                throw (Exception) result;
            }
            
            return result;
        } catch (Exception e) {
            // Try reconnect once
            try {
                socket.close();
                connect();
                
                out.writeObject(methodName);
                out.writeObject(params);
                out.flush();
                
                Object result = in.readObject();
                if (result instanceof Exception) {
                    throw (Exception) result;
                }
                return result;
            } catch (Exception e2) {
                throw new RuntimeException("RPC call failed: " + e2.getMessage(), e2);
            }
        }
    }
    
    @Override
    public boolean login(String username, String password) {
        return (Boolean) invoke("login", username, password);
    }

    @Override
    public boolean register(String username, String password) {
        return (Boolean) invoke("register", username, password);
    }

    @Override
    public boolean logout(String username) {
        return (Boolean) invoke("logout", username);
    }

    @Override
    public boolean savePassword(String username, String account, String password) {
        return (Boolean) invoke("savePassword", username, account, password);
    }

    @Override
    public String getPassword(String username, String account) {
        return (String) invoke("getPassword", username, account);
    }

    @Override
    public boolean deletePassword(String username, String account) {
        return (Boolean) invoke("deletePassword", username, account);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<String, String> getAllPasswords(String username) {
        return (Map<String, String>) invoke("getAllPasswords", username);
    }

    @Override
    public boolean ping() {
        return (Boolean) invoke("ping");
    }
    
    public void close() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (Exception e) {
            // Ignore
        }
    }
}
