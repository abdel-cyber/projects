package com.passwordmanager.client.gui;

import com.passwordmanager.common.PasswordServiceRPC;
import com.passwordmanager.client.PasswordServiceRPCProxy;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ClientGUI extends JFrame 
        implements LoginPanel.LoginListener, PasswordManagerPanel.LogoutListener {
    private final PasswordServiceRPC service;
    private String currentUsername = null;
    
    public ClientGUI(String host, int port) {
        // Create RPC service proxy
        service = new PasswordServiceRPCProxy(host, port);
        
        // Configure frame
        setTitle("Password Manager");
        setSize(900, 700);  // Increased size for better visibility
        setMinimumSize(new Dimension(800, 600)); // Set minimum size
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Show login panel initially
        showLoginPanel();
        
        // Handle window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (currentUsername != null) {
                    try {
                        service.logout(currentUsername);
                    } catch (Exception ex) {
                        // Ignore
                    }
                }
                
                // Close RPC connection
                if (service instanceof PasswordServiceRPCProxy) {
                    ((PasswordServiceRPCProxy) service).close();
                }
            }
        });
    }
    
    private void showLoginPanel() {
        getContentPane().removeAll();
        getContentPane().add(new LoginPanel(service, this));
        validate();
        repaint();
    }
    
    private void showPasswordManagerPanel(String username) {
        getContentPane().removeAll();
        getContentPane().add(new PasswordManagerPanel(service, this, username));
        validate();
        repaint();
    }
    
    @Override
    public void loginSuccessful(String username) {
        currentUsername = username;
        showPasswordManagerPanel(username);
    }
    
    @Override
    public void logout() {
        currentUsername = null;
        showLoginPanel();
    }
    
    public static void main(String[] args) {
        final String host = args.length > 0 ? args[0] : "localhost";
        final int port = args.length > 1 ? Integer.parseInt(args[1]) : 1099;
        
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                // Ignore
            }
            
            ClientGUI client = new ClientGUI(host, port);
            client.setVisible(true);
        });
    }
}
