package com.passwordmanager.client.gui;

import com.passwordmanager.common.PasswordServiceRPC;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.util.Map;
import java.util.Vector;

public class PasswordManagerPanel extends JPanel {
    public interface LogoutListener {
        void logout();
    }
    
    private final PasswordServiceRPC service;
    private final LogoutListener parent;
    private final String username;
    
    private final JTextField accountField;
    private final JPasswordField passwordField;
    private final JTextField searchField;
    private final DefaultTableModel tableModel;
    private final JTable passwordTable;
    private final TableRowSorter<DefaultTableModel> sorter;
    private final JButton logoutButton;
    private final JButton refreshButton;
    private final JButton saveButton;
    private final JButton deleteButton;
    private final JButton copyPassButton;
    private final JButton generateButton;

    public PasswordManagerPanel(PasswordServiceRPC service, LogoutListener parent, String username) {
        this.service = service;
        this.parent = parent;
        this.username = username;
        
        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Top panel with user info and logout
        JPanel topPanel = new JPanel(new BorderLayout(10, 0));
        topPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 15, 5));
        
        // Welcome label with some styling
        JLabel welcomeLabel = new JLabel("Welcome, " + username);
        welcomeLabel.setFont(new Font(welcomeLabel.getFont().getName(), Font.BOLD, 22));
        topPanel.add(welcomeLabel, BorderLayout.WEST);
        
        // Logout button
        logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font(logoutButton.getFont().getName(), Font.BOLD, 16));
        logoutButton.setPreferredSize(new Dimension(120, 40));
        logoutButton.setFocusPainted(false);
        topPanel.add(logoutButton, BorderLayout.EAST);
        
        // Search panel
        JPanel searchPanel = new JPanel(new BorderLayout(10, 0));
        searchPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        searchField = new JTextField();
        searchField.setToolTipText("Search for websites/accounts");
        searchField.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        JLabel searchLabel = new JLabel("Search: ");
        searchLabel.setFont(new Font(searchLabel.getFont().getName(), Font.PLAIN, 16));
        searchPanel.add(searchLabel, BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        
        // Refresh button
        refreshButton = new JButton("Refresh");
        refreshButton.setFont(new Font(refreshButton.getFont().getName(), Font.BOLD, 16));
        refreshButton.setPreferredSize(new Dimension(120, 40));
        refreshButton.setFocusPainted(false);
        searchPanel.add(refreshButton, BorderLayout.EAST);
        
        // Table for passwords with better styling
        String[] columnNames = {"Website/Account", "Password"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        passwordTable = new JTable(tableModel);
        passwordTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        passwordTable.setRowHeight(35);
        passwordTable.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        passwordTable.getTableHeader().setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        passwordTable.setShowGrid(true);
        passwordTable.setGridColor(new Color(230, 230, 230));
        
        // Set column widths
        TableColumnModel columnModel = passwordTable.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(250); // Website column
        columnModel.getColumn(1).setPreferredWidth(200); // Password column
        
        // Add sorter
        sorter = new TableRowSorter<>(tableModel);
        passwordTable.setRowSorter(sorter);
        
        // Create a panel for the form and actions
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createEtchedBorder(), 
            "Add/Edit Password", 
            javax.swing.border.TitledBorder.CENTER, 
            javax.swing.border.TitledBorder.TOP,
            new Font(Font.SANS_SERIF, Font.BOLD, 16)));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Account/Website field
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel accountLabel = new JLabel("Website/Account:");
        accountLabel.setFont(new Font(accountLabel.getFont().getName(), Font.PLAIN, 16));
        formPanel.add(accountLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        accountField = new JTextField(15);
        accountField.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        accountField.setPreferredSize(new Dimension(200, 30));
        formPanel.add(accountField, gbc);
        
        // Password field
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font(passwordLabel.getFont().getName(), Font.PLAIN, 16));
        formPanel.add(passwordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        
        JPanel passwordPanel = new JPanel(new BorderLayout(5, 0));
        passwordField = new JPasswordField();
        passwordField.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        passwordField.setPreferredSize(new Dimension(200, 30));
        generateButton = new JButton("Generate");
        generateButton.setFont(new Font(generateButton.getFont().getName(), Font.BOLD, 14));
        generateButton.setPreferredSize(new Dimension(100, 30));
        generateButton.setFocusPainted(false);
        passwordPanel.add(passwordField, BorderLayout.CENTER);
        passwordPanel.add(generateButton, BorderLayout.EAST);
        formPanel.add(passwordPanel, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        saveButton = new JButton("Save");
        deleteButton = new JButton("Delete");
        copyPassButton = new JButton("Copy Password");
        
        saveButton.setFont(new Font(saveButton.getFont().getName(), Font.BOLD, 16));
        deleteButton.setFont(new Font(deleteButton.getFont().getName(), Font.BOLD, 16));  
        copyPassButton.setFont(new Font(copyPassButton.getFont().getName(), Font.BOLD, 16));
        
        saveButton.setPreferredSize(new Dimension(120, 40));
        deleteButton.setPreferredSize(new Dimension(120, 40));
        copyPassButton.setPreferredSize(new Dimension(180, 40));
        
        saveButton.setFocusPainted(false);
        deleteButton.setFocusPainted(false);
        copyPassButton.setFocusPainted(false);
        
        buttonPanel.add(saveButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(copyPassButton);
        
        // Add button panel to form
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(buttonPanel, gbc);
        
        // Main layout assembly
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(passwordTable), BorderLayout.CENTER);
        
        JPanel southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.add(formPanel, BorderLayout.CENTER);
        
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(southPanel, BorderLayout.SOUTH);
        
        // Add action listeners
        saveButton.addActionListener(e -> onSavePassword());
        deleteButton.addActionListener(e -> onDeletePassword());
        logoutButton.addActionListener(e -> onLogout());
        refreshButton.addActionListener(e -> loadPasswords());
        copyPassButton.addActionListener(e -> onCopyPassword());
        generateButton.addActionListener(e -> generateRandomPassword());
        
        // Search functionality
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updateFilter(); }
            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updateFilter(); }
            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateFilter(); }
            
            private void updateFilter() {
                String text = searchField.getText().trim();
                if (text.isEmpty()) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
        });
        
        // Double-click to fill form
        passwordTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    fillFormFromSelectedRow();
                }
            }
        });
        
        // Select row to fill form
        passwordTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && passwordTable.getSelectedRow() != -1) {
                fillFormFromSelectedRow();
            }
        });
        
        // Load passwords
        loadPasswords();
    }
    
    private void fillFormFromSelectedRow() {
        int viewRow = passwordTable.getSelectedRow();
        if (viewRow != -1) {
            int modelRow = passwordTable.convertRowIndexToModel(viewRow);
            accountField.setText((String)tableModel.getValueAt(modelRow, 0));
            passwordField.setText((String)tableModel.getValueAt(modelRow, 1));
        }
    }
    
    private void loadPasswords() {
        try {
            // Clear table
            tableModel.setRowCount(0);
            
            // Get all passwords
            Map<String, String> passwords = service.getAllPasswords(username);
            
            if (passwords == null) {
                JOptionPane.showMessageDialog(this, "Session expired. Please login again.",
                    "Session Error", JOptionPane.ERROR_MESSAGE);
                parent.logout();
                return;
            }
            
            // Add to table
            for (Map.Entry<String, String> entry : passwords.entrySet()) {
                Vector<String> row = new Vector<>();
                row.add(entry.getKey());
                row.add(entry.getValue());
                tableModel.addRow(row);
            }
            
            accountField.setText("");
            passwordField.setText("");
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading passwords: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void onSavePassword() {
        String account = accountField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        if (account.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Website/account and password cannot be empty",
                "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            if (service.savePassword(username, account, password)) {
                loadPasswords();
                accountField.setText("");
                passwordField.setText("");
                JOptionPane.showMessageDialog(this, "Password saved successfully",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save password. Please check your session.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void onDeletePassword() {
        int selectedRow = passwordTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a password to delete",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int modelRow = passwordTable.convertRowIndexToModel(selectedRow);
        String account = (String) tableModel.getValueAt(modelRow, 0);
        
        if (JOptionPane.showConfirmDialog(this, "Delete password for " + account + "?",
            "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                if (service.deletePassword(username, account)) {
                    loadPasswords();
                    JOptionPane.showMessageDialog(this, "Password deleted successfully",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete password",
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void onCopyPassword() {
        int selectedRow = passwordTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a password to copy",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int modelRow = passwordTable.convertRowIndexToModel(selectedRow);
        String password = (String) tableModel.getValueAt(modelRow, 1);
        
        StringSelection selection = new StringSelection(password);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection, null);
        
        JOptionPane.showMessageDialog(this, "Password copied to clipboard",
            "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void generateRandomPassword() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+";
        StringBuilder sb = new StringBuilder();
        java.util.Random random = new java.util.Random();
        
        for (int i = 0; i < 12; i++) {
            int index = random.nextInt(chars.length());
            sb.append(chars.charAt(index));
        }
        
        passwordField.setText(sb.toString());
    }
    
    private void onLogout() {
        try {
            service.logout(username);
            parent.logout();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error logging out: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
            parent.logout(); // Force logout
        }
    }
}
