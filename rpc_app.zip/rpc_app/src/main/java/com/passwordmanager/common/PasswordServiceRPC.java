package com.passwordmanager.common;

import java.io.Serializable;
import java.util.Map;

public interface PasswordServiceRPC extends Serializable {
    boolean login(String username, String password);
    boolean register(String username, String password);
    boolean logout(String username);
    boolean savePassword(String username, String account, String password);
    String getPassword(String username, String account);
    boolean deletePassword(String username, String account);
    Map<String, String> getAllPasswords(String username);
    boolean ping();
}
