package com.passwordmanager.server.gui;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ServerGUI extends JFrame {
    private JTextArea logArea;
    private JTextField portField;
    private JButton startButton;
    private JButton stopButton;
    private JLabel statusLabel;
    private final List<LogObserver> observers = new ArrayList<>();
    private DefaultListModel<String> activeUsersModel;
    private JTable clientTable;
    
    private boolean isRunning = false;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public interface LogObserver {
        void onServerStart(int port);
        void onServerStop();
        void onLogClear();
    }
    
    public ServerGUI() {
        setTitle("Password Manager Server");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create UI components
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Server control panel
        JPanel serverPanel = new JPanel(new BorderLayout(5, 5));
        serverPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Control panel
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
        
        // Status panel
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusLabel = new JLabel("Server Stopped");
        statusLabel.setFont(statusLabel.getFont().deriveFont(Font.BOLD));
        statusLabel.setHorizontalAlignment(JLabel.CENTER);
        statusPanel.add(statusLabel, BorderLayout.CENTER);
        
        // Port configuration panel
        JPanel portPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        portPanel.add(new JLabel("Port:"));
        portField = new JTextField("1099", 5);
        portPanel.add(portField);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        startButton = new JButton("Start Server");
        stopButton = new JButton("Stop Server");
        JButton clearButton = new JButton("Clear Log");
        
        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        buttonPanel.add(clearButton);
        
        // Add to control panel
        controlPanel.add(statusPanel);
        controlPanel.add(Box.createVerticalStrut(10));
        controlPanel.add(portPanel);
        controlPanel.add(Box.createVerticalStrut(10));
        controlPanel.add(buttonPanel);
        
        // Log area with scrolling
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane logScrollPane = new JScrollPane(logArea);
        
        // Auto-scroll logs
        DefaultCaret caret = (DefaultCaret) logArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        
        // Add to server panel
        serverPanel.add(controlPanel, BorderLayout.NORTH);
        serverPanel.add(logScrollPane, BorderLayout.CENTER);
        
        // Client monitoring panel
        JPanel clientsPanel = new JPanel(new BorderLayout(5, 5));
        clientsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table model for client activities
        String[] columnNames = {"Time", "Client IP", "Username", "Action", "Details"};
        Object[][] data = {};
        clientTable = new JTable(new javax.swing.table.DefaultTableModel(data, columnNames));
        JScrollPane clientScrollPane = new JScrollPane(clientTable);
        
        // Active users list
        activeUsersModel = new DefaultListModel<>();
        JList<String> activeUsersList = new JList<>(activeUsersModel);
        activeUsersList.setBorder(BorderFactory.createTitledBorder("Active Users"));
        JScrollPane usersScrollPane = new JScrollPane(activeUsersList);
        usersScrollPane.setPreferredSize(new Dimension(150, 0));
        
        // Add components to clients panel
        clientsPanel.add(usersScrollPane, BorderLayout.WEST);
        clientsPanel.add(clientScrollPane, BorderLayout.CENTER);
        
        // Add all tabs to the tabbed pane
        tabbedPane.addTab("Server Control", serverPanel);
        tabbedPane.addTab("Client Activity", clientsPanel);
        
        // Add tabbed pane to frame
        setContentPane(tabbedPane);
        
        // Add action listeners
        startButton.addActionListener(e -> startServer());
        stopButton.addActionListener(e -> stopServer());
        clearButton.addActionListener(e -> clearLog());
        
        updateButtonState();
    }
    
    public void addLogObserver(LogObserver observer) {
        observers.add(observer);
    }
    
    private void startServer() {
        int port;
        try {
            port = Integer.parseInt(portField.getText().trim());
            if (port < 1 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid port number (1-65535)");
            return;
        }
        
        isRunning = true;
        updateButtonState();
        log("Starting server on port " + port + "...");
        
        for (LogObserver observer : observers) {
            observer.onServerStart(port);
        }
    }
    
    private void stopServer() {
        log("Stopping server...");
        isRunning = false;
        updateButtonState();
        
        for (LogObserver observer : observers) {
            observer.onServerStop();
        }
        
        activeUsersModel.clear();
    }
    
    private void clearLog() {
        logArea.setText("");
        for (LogObserver observer : observers) {
            observer.onLogClear();
        }
    }
    
    private void updateButtonState() {
        startButton.setEnabled(!isRunning);
        stopButton.setEnabled(isRunning);
        portField.setEnabled(!isRunning);
        statusLabel.setText(isRunning ? "Server Running" : "Server Stopped");
        statusLabel.setForeground(isRunning ? new Color(0, 128, 0) : Color.RED);
    }
    
    public void log(String message) {
        String timestamp = dateFormat.format(new Date());
        SwingUtilities.invokeLater(() -> {
            logArea.append("[" + timestamp + "] " + message + "\n");
        });
    }
    
    public void addClientActivity(String clientIp, String username, String action, String details) {
        String timestamp = dateFormat.format(new Date());
        SwingUtilities.invokeLater(() -> {
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) clientTable.getModel();
            model.addRow(new Object[]{timestamp, clientIp, username, action, details});
        });
    }
    
    public void addActiveUser(String username) {
        SwingUtilities.invokeLater(() -> {
            if (!activeUsersModel.contains(username)) {
                activeUsersModel.addElement(username);
            }
        });
    }
    
    public void removeActiveUser(String username) {
        SwingUtilities.invokeLater(() -> {
            activeUsersModel.removeElement(username);
        });
    }
}
