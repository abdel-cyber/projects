package com.passwordmanager.server;

import com.passwordmanager.common.PasswordServiceRPC;
import java.io.*;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.regex.Pattern;

public class PasswordServiceRPCImpl implements PasswordServiceRPC {
    private static final long serialVersionUID = 1L;
    private final Map<String, String> users = new ConcurrentHashMap<>();
    private final Map<String, Map<String, String>> passwords = new ConcurrentHashMap<>();
    private final Map<String, Boolean> loggedInUsers = new ConcurrentHashMap<>();
    private final String DATA_DIR = "data";
    private final String USERS_FILE = DATA_DIR + "/users.dat";
    private final String PASSWORDS_FILE = DATA_DIR + "/passwords.dat";
    
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]{3,20}$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^.{6,}$");
    
    // Logger callback
    private final Consumer<String> logger;

    public PasswordServiceRPCImpl(Consumer<String> logger) {
        this.logger = logger;
        loadData();
    }
    
    @Override
    public boolean login(String username, String password) {
        if (!validateUsername(username) || !validatePassword(password)) {
            logger.accept("Invalid login attempt with malformed credentials");
            return false;
        }

        if (users.containsKey(username) && users.get(username).equals(hashPassword(password))) {
            loggedInUsers.put(username, true);
            logger.accept("User logged in: " + username);
            return true;
        }
        logger.accept("Failed login attempt for user: " + username);
        return false;
    }

    @Override
    public boolean register(String username, String password) {
        if (!validateUsername(username) || !validatePassword(password)) {
            logger.accept("Registration failed: Invalid credentials format");
            return false;
        }
        
        if (users.containsKey(username)) {
            logger.accept("Registration failed: Username already exists: " + username);
            return false;
        }
        
        users.put(username, hashPassword(password));
        passwords.put(username, new HashMap<>());
        saveData();
        logger.accept("New user registered: " + username);
        return true;
    }

    @Override
    public boolean logout(String username) {
        if (loggedInUsers.containsKey(username)) {
            loggedInUsers.remove(username);
            logger.accept("User logged out: " + username);
            return true;
        }
        return false;
    }

    @Override
    public boolean savePassword(String username, String account, String password) {
        if (!isUserLoggedIn(username)) {
            logger.accept("Unauthorized attempt to save password for user: " + username);
            return false;
        }
        
        Map<String, String> userPasswords = passwords.get(username);
        if (userPasswords == null) {
            userPasswords = new HashMap<>();
            passwords.put(username, userPasswords);
        }
        
        userPasswords.put(account, password);
        saveData();
        logger.accept("Password saved for user " + username + ", account: " + account);
        return true;
    }

    @Override
    public String getPassword(String username, String account) {
        if (!isUserLoggedIn(username)) {
            logger.accept("Unauthorized attempt to retrieve password for user: " + username);
            return null;
        }
        
        Map<String, String> userPasswords = passwords.get(username);
        String result = userPasswords != null ? userPasswords.get(account) : null;
        logger.accept("Password retrieved for user " + username + ", account: " + account);
        return result;
    }

    @Override
    public boolean deletePassword(String username, String account) {
        if (!isUserLoggedIn(username)) {
            logger.accept("Unauthorized attempt to delete password for user: " + username);
            return false;
        }
        
        Map<String, String> userPasswords = passwords.get(username);
        if (userPasswords != null && userPasswords.containsKey(account)) {
            userPasswords.remove(account);
            saveData();
            logger.accept("Password deleted for user " + username + ", account: " + account);
            return true;
        }
        return false;
    }

    @Override
    public Map<String, String> getAllPasswords(String username) {
        if (!isUserLoggedIn(username)) {
            logger.accept("Unauthorized attempt to retrieve all passwords for user: " + username);
            return null;
        }
        
        logger.accept("All passwords retrieved for user: " + username);
        return new HashMap<>(passwords.getOrDefault(username, new HashMap<>()));
    }

    @Override
    public boolean ping() {
        return true;
    }

    private boolean isUserLoggedIn(String username) {
        return loggedInUsers.containsKey(username) && loggedInUsers.get(username);
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedhash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            logger.accept("Error hashing password: " + e.getMessage());
            return password;
        }
    }
    
    private boolean validateUsername(String username) {
        return username != null && USERNAME_PATTERN.matcher(username).matches();
    }
    
    private boolean validatePassword(String password) {
        return password != null && PASSWORD_PATTERN.matcher(password).matches();
    }

    @SuppressWarnings("unchecked")
    private void loadData() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
            logger.accept("Created data directory: " + dir.getAbsolutePath());
        }
        
        try {
            File usersFile = new File(USERS_FILE);
            if (usersFile.exists()) {
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(usersFile))) {
                    users.putAll((Map<String, String>) ois.readObject());
                    logger.accept("Loaded " + users.size() + " users");
                }
            }
            
            File passwordsFile = new File(PASSWORDS_FILE);
            if (passwordsFile.exists()) {
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(passwordsFile))) {
                    passwords.putAll((Map<String, Map<String, String>>) ois.readObject());
                    logger.accept("Loaded passwords database");
                }
            }
        } catch (Exception e) {
            logger.accept("Error loading data: " + e.getMessage());
        }
    }

    private void saveData() {
        try {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USERS_FILE))) {
                oos.writeObject(new HashMap<>(users));
            }
            
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PASSWORDS_FILE))) {
                oos.writeObject(new HashMap<>(passwords));
            }
            
            logger.accept("Data saved successfully");
        } catch (Exception e) {
            logger.accept("Error saving data: " + e.getMessage());
        }
    }
}
