package com.passwordmanager.server;

import com.passwordmanager.common.PasswordServiceRPC;
import com.passwordmanager.server.gui.ServerGUI;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.util.Map;

public class RPCServer implements ServerGUI.LogObserver {
    private ServerSocket serverSocket;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private ExecutorService threadPool;
    private final ServerGUI gui;
    private PasswordServiceRPCImpl service;
    private final Map<String, String> clientAddresses = new ConcurrentHashMap<>();
    
    public RPCServer() {
        gui = new ServerGUI();
        gui.addLogObserver(this);
        service = new PasswordServiceRPCImpl(this::logAction);
    }
    
    public void start() {
        gui.setVisible(true);
    }
    
    @Override
    public void onServerStart(int port) {
        if (running.get()) {
            gui.log("Server is already running!");
            return;
        }
        
        try {
            threadPool = Executors.newFixedThreadPool(10);
            serverSocket = new ServerSocket(port);
            running.set(true);
            
            gui.log("Server started on port " + port);
            
            new Thread(this::acceptConnections).start();
            
        } catch (Exception e) {
            gui.log("Error starting server: " + e.getMessage());
            stopServer();
        }
    }
    
    @Override
    public void onServerStop() {
        stopServer();
    }
    
    @Override
    public void onLogClear() {
        // Nothing to do
    }
    
    private void acceptConnections() {
        gui.log("Waiting for client connections...");
        
        while (running.get()) {
            try {
                Socket clientSocket = serverSocket.accept();
                String clientAddress = clientSocket.getInetAddress().getHostAddress();
                gui.log("Client connected from " + clientAddress);
                
                threadPool.submit(() -> handleClient(clientSocket));
                
            } catch (Exception e) {
                if (running.get()) {
                    gui.log("Connection error: " + e.getMessage());
                }
            }
        }
    }
    
    private void handleClient(Socket clientSocket) {
        String clientAddress = clientSocket.getInetAddress().getHostAddress();
        
        try (
            ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())
        ) {
            while (running.get() && !clientSocket.isClosed()) {
                try {
                    String methodName = (String) in.readObject();
                    Object[] params = (Object[]) in.readObject();
                    
                    Object result = null;
                    
                    switch (methodName) {
                        case "login":
                            result = service.login((String) params[0], (String) params[1]);
                            if ((Boolean) result) {
                                clientAddresses.put((String) params[0], clientAddress);
                                gui.addActiveUser((String) params[0]);
                            }
                            break;
                        case "register":
                            result = service.register((String) params[0], (String) params[1]);
                            break;
                        case "logout":
                            result = service.logout((String) params[0]);
                            if ((Boolean) result) {
                                clientAddresses.remove((String) params[0]);
                                gui.removeActiveUser((String) params[0]);
                            }
                            break;
                        case "savePassword":
                            result = service.savePassword((String) params[0], (String) params[1], (String) params[2]);
                            if((Boolean) result) {
                                gui.addClientActivity(clientAddress, (String) params[0], "SAVE", params[1].toString());
                            }
                            break;
                        case "getPassword":
                            result = service.getPassword((String) params[0], (String) params[1]);
                            gui.addClientActivity(clientAddress, (String) params[0], "GET", params[1].toString());
                            break;
                        case "deletePassword":
                            result = service.deletePassword((String) params[0], (String) params[1]);
                            if((Boolean) result) {
                                gui.addClientActivity(clientAddress, (String) params[0], "DELETE", params[1].toString());
                            }
                            break;
                        case "getAllPasswords":
                            result = service.getAllPasswords((String) params[0]);
                            gui.addClientActivity(clientAddress, (String) params[0], "LIST", "Retrieved passwords");
                            break;
                        case "ping":
                            result = service.ping();
                            break;
                        default:
                            throw new IllegalArgumentException("Unknown method: " + methodName);
                    }
                    
                    out.writeObject(result);
                    out.flush();
                    
                } catch (Exception e) {
                    gui.log("Error from " + clientAddress + ": " + e.getMessage());
                    try {
                        out.writeObject(new Exception("Server error: " + e.getMessage()));
                        out.flush();
                        break;
                    } catch (Exception ex) {
                        break;
                    }
                }
            }
        } catch (Exception e) {
            gui.log("Error with client " + clientAddress + ": " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
                gui.log("Client " + clientAddress + " disconnected");
                
                for (Map.Entry<String, String> entry : clientAddresses.entrySet()) {
                    if (entry.getValue().equals(clientAddress)) {
                        gui.removeActiveUser(entry.getKey());
                        clientAddresses.remove(entry.getKey());
                        break;
                    }
                }
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    private void stopServer() {
        if (!running.getAndSet(false)) {
            gui.log("Server is already stopped");
            return;
        }
        
        gui.log("Shutting down server...");
        
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
            
            if (threadPool != null) {
                threadPool.shutdown();
            }
            
            clientAddresses.clear();
            
            gui.log("Server has been stopped");
        } catch (Exception e) {
            gui.log("Error stopping server: " + e.getMessage());
        }
    }
    
    public void logAction(String message) {
        if (gui != null) {
            SwingUtilities.invokeLater(() -> gui.log(message));
        }
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Fallback to default
        }
        
        SwingUtilities.invokeLater(() -> {
            RPCServer server = new RPCServer();
            server.start();
        });
    }
}
