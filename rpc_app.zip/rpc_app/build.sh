#!/bin/bash

echo "Building RPC Password Manager..."
cd "$(dirname "$0")"

# Create bin directory
mkdir -p bin

# Compile in proper order
echo "Compiling interface..."
javac -d bin src/main/java/com/passwordmanager/common/PasswordServiceRPC.java

echo "Compiling server implementation..."
javac -d bin -cp bin src/main/java/com/passwordmanager/server/gui/ServerGUI.java
javac -d bin -cp bin src/main/java/com/passwordmanager/server/PasswordServiceRPCImpl.java
javac -d bin -cp bin src/main/java/com/passwordmanager/server/RPCServer.java

echo "Compiling client proxy..."
javac -d bin -cp bin src/main/java/com/passwordmanager/client/PasswordServiceRPCProxy.java

echo "Compiling GUI classes..."
javac -d bin -cp bin src/main/java/com/passwordmanager/client/gui/LoginPanel.java
javac -d bin -cp bin src/main/java/com/passwordmanager/client/gui/PasswordManagerPanel.java
javac -d bin -cp bin src/main/java/com/passwordmanager/client/gui/ClientGUI.java

echo "Compiling main client..."
javac -d bin -cp bin src/main/java/com/passwordmanager/client/RPCClient.java

echo "Build completed!"
