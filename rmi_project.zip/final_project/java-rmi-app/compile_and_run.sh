#!/bin/bash

echo "Java RMI Password Manager"
echo "========================="

# Créer les répertoires nécessaires
mkdir -p classes
mkdir -p src/main/resources/icons

# Compiler
compile() {
    echo "Compiling application..."
    
    javac -d classes src/main/java/com/rmiapp/common/RMIInterface.java
    if [ $? -ne 0 ]; then echo "Failed to compile interface"; exit 1; fi
    
    javac -d classes -cp classes src/main/java/com/rmiapp/server/gui/ServerGUI.java
    if [ $? -ne 0 ]; then echo "Failed to compile server GUI"; exit 1; fi
    
    javac -d classes -cp classes src/main/java/com/rmiapp/server/service/PasswordService.java
    if [ $? -ne 0 ]; then echo "Failed to compile service"; exit 1; fi
    
    javac -d classes -cp classes src/main/java/com/rmiapp/client/gui/ModernClientGUI.java
    if [ $? -ne 0 ]; then echo "Failed to compile client GUI"; exit 1; fi
    
    javac -d classes -cp classes src/main/java/RMIServer.java src/main/java/RMIClient.java
    if [ $? -ne 0 ]; then echo "Failed to compile main classes"; exit 1; fi
    
    # Copy resources
    cp -r src/main/resources classes/
    
    echo "Compilation successful!"
}

# Exécuter le serveur
run_server() {
    echo "Starting RMI Server..."
    cd ~/Desktop/final_project/java-rmi-app/
    java -cp classes RMIServer
}

# Exécuter le client
run_client() {
    echo "Starting RMI Client..."
    cd ~/Desktop/final_project/java-rmi-app/
    java -cp classes RMIClient $1
}

case "$1" in
    compile)
        compile
        ;;
    server)
        run_server
        ;;
    client)
        run_client $2
        ;;
    *)
        echo "Usage: $0 [compile|server|client]"
        echo "  compile - Compile the application"
        echo "  server  - Run the RMI server"
        echo "  client  - Run the RMI client (add hostname as optional parameter)"
        exit 1
esac
