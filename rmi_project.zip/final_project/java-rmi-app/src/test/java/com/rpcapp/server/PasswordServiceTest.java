import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.rpcapp.server.service.PasswordService;
import com.rpcapp.server.database.PasswordRepository;
import com.rpcapp.common.model.Password;

public class PasswordServiceTest {
    private PasswordService passwordService;
    private PasswordRepository passwordRepository;

    @BeforeEach
    public void setUp() {
        passwordRepository = new PasswordRepository();
        passwordService = new PasswordService(passwordRepository);
    }

    @Test
    public void testStorePassword() {
        Password password = new Password("user1", "hashedPassword123");
        passwordService.storePassword(password);
        assertEquals(password, passwordRepository.findByUsername("user1"));
    }

    @Test
    public void testRetrievePassword() {
        Password password = new Password("user2", "hashedPassword456");
        passwordService.storePassword(password);
        Password retrievedPassword = passwordService.retrievePassword("user2");
        assertEquals(password.getUsername(), retrievedPassword.getUsername());
        assertEquals(password.getHashedPassword(), retrievedPassword.getHashedPassword());
    }

    @Test
    public void testRetrieveNonExistentPassword() {
        Password retrievedPassword = passwordService.retrievePassword("nonExistentUser");
        assertNull(retrievedPassword);
    }
}