import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.rpcapp.client.security.PasswordManager;

public class PasswordManagerTest {
    private PasswordManager passwordManager;

    @BeforeEach
    public void setUp() {
        passwordManager = new PasswordManager();
    }

    @Test
    public void testStorePassword() {
        String username = "testUser";
        String password = "testPassword";
        assertTrue(passwordManager.storePassword(username, password));
    }

    @Test
    public void testRetrievePassword() {
        String username = "testUser";
        String password = "testPassword";
        passwordManager.storePassword(username, password);
        String retrievedPassword = passwordManager.retrievePassword(username);
        assertEquals(password, retrievedPassword);
    }

    @Test
    public void testRetrieveNonExistentPassword() {
        String username = "nonExistentUser";
        String retrievedPassword = passwordManager.retrievePassword(username);
        assertNull(retrievedPassword);
    }

    @Test
    public void testPasswordHashing() {
        String password = "testPassword";
        String hashedPassword = passwordManager.hashPassword(password);
        assertNotEquals(password, hashedPassword);
        assertTrue(passwordManager.verifyPassword(password, hashedPassword));
    }
}