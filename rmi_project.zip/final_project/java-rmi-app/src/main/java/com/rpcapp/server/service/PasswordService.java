package com.rpcapp.server.service;

import com.rpcapp.common.RPCInterface;
import java.rmi.RemoteException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PasswordService implements RPCInterface {
    private Map<String, String> users;  // username -> hashed password
    private Map<String, Map<String, String>> passwords;  // username -> (account -> password)
    private Map<String, Long> lastActivity;  // username -> timestamp of last activity
    private static final long SESSION_TIMEOUT = 15 * 60 * 1000;  // 15 minutes in ms
    
    public PasswordService() {
        users = new ConcurrentHashMap<>();
        passwords = new ConcurrentHashMap<>();
        lastActivity = new ConcurrentHashMap<>();
        
        // Add demo users
        try {
            users.put("admin", hashPassword("admin123"));
            users.put("user1", hashPassword("password123"));
            
            Map<String, String> adminAccounts = new HashMap<>();
            adminAccounts.put("gmail", "admin_gmail_pass");
            adminAccounts.put("facebook", "admin_fb_pass");
            passwords.put("admin", adminAccounts);
            
            Map<String, String> user1Accounts = new HashMap<>();
            user1Accounts.put("twitter", "user1_twitter_pass");
            passwords.put("user1", user1Accounts);
        } catch (Exception e) {
            System.err.println("Error initializing default accounts: " + e.getMessage());
        }
    }
    
    @Override
    public boolean ping() throws RemoteException {
        return true;
    }
    
    @Override
    public boolean authenticate(String username, String password) throws RemoteException {
        // Input validation
        if (username == null || password == null || 
            username.trim().isEmpty() || password.trim().isEmpty()) {
            System.err.println("Authentication attempt with invalid credentials");
            return false;
        }
        
        // Validate username format (alphanumeric only)
        if (!username.matches("^[a-zA-Z0-9]+$")) {
            System.err.println("Invalid username format attempt: " + username);
            return false;
        }
        
        if (!users.containsKey(username)) {
            // If user doesn't exist, create a new account
            try {
                users.put(username, hashPassword(password));
                passwords.put(username, new HashMap<>());
                System.out.println("Created new user: " + username);
                updateLastActivity(username);
                return true;
            } catch (Exception e) {
                System.err.println("Error creating user: " + e.getMessage());
                return false;
            }
        }
        
        try {
            String hashedPassword = hashPassword(password);
            boolean success = hashedPassword.equals(users.get(username));
            if (success) {
                updateLastActivity(username);
            } else {
                System.err.println("Failed authentication attempt for user: " + username);
            }
            return success;
        } catch (Exception e) {
            System.err.println("Authentication error: " + e.getMessage());
            return false;
        }
    }
    
    @Override
    public boolean savePassword(String account, String password, String username) throws RemoteException {
        if (!validateSession(username)) {
            return false;
        }
        
        // Input validation
        if (account == null || password == null || account.trim().isEmpty()) {
            return false;
        }
        
        Map<String, String> userAccounts = passwords.get(username);
        if (userAccounts == null) {
            userAccounts = new HashMap<>();
            passwords.put(username, userAccounts);
        }
        
        userAccounts.put(account, password);
        System.out.println("Saved password for " + username + ":" + account);
        updateLastActivity(username);
        return true;
    }
    
    @Override
    public String getPassword(String account, String username) throws RemoteException {
        if (!validateSession(username)) {
            return null;
        }
        
        // Input validation
        if (account == null || account.trim().isEmpty()) {
            return null;
        }
        
        Map<String, String> userAccounts = passwords.get(username);
        if (userAccounts == null) {
            return null;
        }
        
        updateLastActivity(username);
        return userAccounts.get(account);
    }
    
    @Override
    public boolean deletePassword(String account, String username) throws RemoteException {
        if (!validateSession(username)) {
            return false;
        }
        
        // Input validation
        if (account == null || account.trim().isEmpty()) {
            return false;
        }
        
        Map<String, String> userAccounts = passwords.get(username);
        if (userAccounts == null || !userAccounts.containsKey(account)) {
            return false;
        }
        
        userAccounts.remove(account);
        System.out.println("Deleted password for " + username + ":" + account);
        updateLastActivity(username);
        return true;
    }
    
    @Override
    public Map<String, String> getAllAccounts(String username) throws RemoteException {
        if (!validateSession(username)) {
            return new HashMap<>();
        }
        
        Map<String, String> userAccounts = passwords.get(username);
        if (userAccounts == null) {
            return new HashMap<>();
        }
        
        updateLastActivity(username);
        return new HashMap<>(userAccounts);
    }
    
    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = md.digest(password.getBytes());
        return Base64.getEncoder().encodeToString(hashedBytes);
    }
    
    private void updateLastActivity(String username) {
        lastActivity.put(username, System.currentTimeMillis());
    }
    
    private boolean validateSession(String username) {
        if (!users.containsKey(username)) {
            return false;
        }
        
        Long lastActivityTime = lastActivity.get(username);
        if (lastActivityTime == null) {
            return false;
        }
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastActivityTime > SESSION_TIMEOUT) {
            System.out.println("Session timeout for user: " + username);
            return false;
        }
        
        return true;
    }
}
