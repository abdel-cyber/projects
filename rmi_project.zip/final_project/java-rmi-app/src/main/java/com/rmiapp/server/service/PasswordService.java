package com.rmiapp.server.service;

import com.rmiapp.common.RMIInterface;
import com.rmiapp.server.gui.ServerGUI;

import java.rmi.RemoteException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PasswordService implements RMIInterface {
    private Map<String, String> users;  // username -> hashed password
    private Map<String, Map<String, String>> passwords;  // username -> (account -> password en clair)
    private Map<String, Long> lastActivity;  // username -> timestamp of last activity
    private static final long SESSION_TIMEOUT = 15 * 60 * 1000;  // 15 minutes in ms
    private ServerGUI gui;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public PasswordService() {
        this(null);
    }
    
    public PasswordService(ServerGUI gui) {
        this.gui = gui;
        users = new ConcurrentHashMap<>();
        passwords = new ConcurrentHashMap<>();
        lastActivity = new ConcurrentHashMap<>();
        
        // Add demo users
        try {
            users.put("admin", hashPassword("admin123"));
            users.put("user1", hashPassword("password123"));
            
            Map<String, String> adminAccounts = new HashMap<>();
            adminAccounts.put("gmail", "admin_gmail_pass"); // Mot de passe en clair
            adminAccounts.put("facebook", "admin_fb_pass"); // Mot de passe en clair
            passwords.put("admin", adminAccounts);
            
            Map<String, String> user1Accounts = new HashMap<>();
            user1Accounts.put("twitter", "user1_twitter_pass"); // Mot de passe en clair
            passwords.put("user1", user1Accounts);
            
            log("Initialized with default accounts: admin, user1");
            
            // Update GUI with initial users
            if (gui != null) {
                gui.updateUserInfo("admin", "N/A", adminAccounts.size(), false);
                gui.updateUserInfo("user1", "N/A", user1Accounts.size(), false);
            }
            
        } catch (Exception e) {
            log("Error initializing default accounts: " + e.getMessage());
        }
    }
    
    @Override
    public boolean ping() throws RemoteException {
        return true;
    }
    
    @Override
    public boolean authenticate(String username, String password) throws RemoteException {
        // Input validation
        if (username == null || password == null || 
            username.trim().isEmpty() || password.trim().isEmpty()) {
            log("Authentication attempt with invalid credentials");
            return false;
        }
        
        if (!users.containsKey(username)) {
            // If user doesn't exist, create a new account
            try {
                users.put(username, hashPassword(password));
                passwords.put(username, new HashMap<>());
                updateLastActivity(username);
                log("Created new user: " + username);
                
                if (gui != null) {
                    gui.updateUserInfo(username, dateFormat.format(new Date()), 0, true);
                    gui.addUserActivity(username, "ACCOUNT CREATED", "New user account");
                    gui.incrementConnections();
                }
                
                return true;
            } catch (Exception e) {
                log("Error creating user: " + e.getMessage());
                return false;
            }
        }
        
        try {
            String hashedPassword = hashPassword(password);
            boolean success = hashedPassword.equals(users.get(username));
            if (success) {
                updateLastActivity(username);
                log("User authenticated: " + username);
                
                if (gui != null) {
                    gui.updateUserInfo(username, dateFormat.format(new Date()), 
                        passwords.get(username) != null ? passwords.get(username).size() : 0,
                        true);
                    gui.addUserActivity(username, "LOGGED IN", "Authentication successful");
                    gui.incrementConnections();
                }
            } else {
                log("Failed authentication attempt for user: " + username);
                if (gui != null) {
                    gui.addUserActivity(username, "LOGIN FAILED", "Incorrect password");
                }
            }
            return success;
        } catch (Exception e) {
            log("Authentication error: " + e.getMessage());
            return false;
        }
    }
    
    @Override
    public boolean savePassword(String account, String password, String username) throws RemoteException {
        if (!validateSession(username)) {
            log("Session validation failed for user: " + username);
            return false;
        }
        
        // Input validation
        if (account == null || password == null || account.trim().isEmpty()) {
            log("Invalid input for savePassword: account=" + account);
            return false;
        }
        
        Map<String, String> userAccounts = passwords.get(username);
        if (userAccounts == null) {
            userAccounts = new HashMap<>();
            passwords.put(username, userAccounts);
        }
        
        boolean isUpdate = userAccounts.containsKey(account);
        
        // IMPORTANT: Stockage du mot de passe en clair (non haché)
        userAccounts.put(account, password);
        
        log(username + " saved password for: " + account + ", value: " + password);
        updateLastActivity(username);
        
        if (gui != null) {
            gui.updateUserInfo(username, dateFormat.format(new Date()), userAccounts.size(), true);
            gui.addUserActivity(username, isUpdate ? "UPDATED PASSWORD" : "SAVED PASSWORD", 
                "Account: " + account);
        }
        
        return true;
    }
    
    @Override
    public String getPassword(String account, String username) throws RemoteException {
        if (!validateSession(username)) {
            log("Session validation failed for user: " + username + " when getting password");
            return null;
        }
        
        // Input validation
        if (account == null || account.trim().isEmpty()) {
            log("Invalid account name for getPassword: " + username);
            return null;
        }
        
        Map<String, String> userAccounts = passwords.get(username);
        if (userAccounts == null) {
            log("No accounts found for user: " + username);
            return null;
        }
        
        String password = userAccounts.get(account);
        
        if (password != null) {
            // DEBUG: Afficher le mot de passe explicitement dans les logs du serveur
            log(username + " retrieved password for: " + account + ", returning value: " + password);
            updateLastActivity(username);
            
            if (gui != null) {
                gui.updateUserInfo(username, dateFormat.format(new Date()), userAccounts.size(), true);
                gui.addUserActivity(username, "RETRIEVED PASSWORD", "Account: " + account);
            }
        } else {
            log(username + " attempted to retrieve non-existent password for: " + account);
        }
        
        // Retourne directement le mot de passe stocké (qui est en clair)
        return password;
    }
    
    @Override
    public boolean deletePassword(String account, String username) throws RemoteException {
        if (!validateSession(username)) {
            log("Session validation failed for user: " + username + " when deleting password");
            return false;
        }
        
        // Input validation
        if (account == null || account.trim().isEmpty()) {
            log("Invalid account name for deletePassword: " + username);
            return false;
        }
        
        Map<String, String> userAccounts = passwords.get(username);
        if (userAccounts == null || !userAccounts.containsKey(account)) {
            log("Account not found for deletion: " + account + " for user " + username);
            return false;
        }
        
        userAccounts.remove(account);
        log(username + " deleted password for: " + account);
        updateLastActivity(username);
        
        if (gui != null) {
            gui.updateUserInfo(username, dateFormat.format(new Date()), userAccounts.size(), true);
            gui.addUserActivity(username, "DELETED PASSWORD", "Account: " + account);
        }
        
        return true;
    }
    
    @Override
    public Map<String, String> getAllAccounts(String username) throws RemoteException {
        if (!validateSession(username)) {
            log("Session validation failed for user: " + username + " when getting all accounts");
            return new HashMap<>();
        }
        
        Map<String, String> userAccounts = passwords.get(username);
        if (userAccounts == null) {
            log("No accounts found for user when listing: " + username);
            return new HashMap<>();
        }
        
        log(username + " retrieved all accounts (count: " + userAccounts.size() + ")");
        updateLastActivity(username);
        
        if (gui != null) {
            gui.updateUserInfo(username, dateFormat.format(new Date()), userAccounts.size(), true);
            gui.addUserActivity(username, "LISTED ACCOUNTS", "Retrieved all stored passwords");
        }
        
        return new HashMap<>(userAccounts);
    }
    
    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = md.digest(password.getBytes());
        return Base64.getEncoder().encodeToString(hashedBytes);
    }
    
    private void updateLastActivity(String username) {
        lastActivity.put(username, System.currentTimeMillis());
    }
    
    private boolean validateSession(String username) {
        if (!users.containsKey(username)) {
            log("Session validation: User does not exist: " + username);
            return false;
        }
        
        Long lastActivityTime = lastActivity.get(username);
        if (lastActivityTime == null) {
            log("Session validation: No activity record for: " + username);
            return false;
        }
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastActivityTime > SESSION_TIMEOUT) {
            log("Session timeout for user: " + username);
            
            if (gui != null) {
                gui.updateUserInfo(username, dateFormat.format(new Date()), 
                    passwords.get(username) != null ? passwords.get(username).size() : 0,
                    false);
                gui.addUserActivity(username, "SESSION EXPIRED", "Timeout after inactivity");
                gui.decrementConnections();
            }
            
            return false;
        }
        
        return true;
    }
    
    private void log(String message) {
        if (gui != null) {
            gui.log(message);
        } else {
            System.out.println(message);
        }
    }
}
