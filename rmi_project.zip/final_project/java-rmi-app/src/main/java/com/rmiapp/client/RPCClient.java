package com.rpcapp.client;

import com.rpcapp.client.gui.ClientGUI;
import com.rpcapp.client.security.Authenticator;

import javax.swing.*;

public class RPCClient {
    private Authenticator authenticator;

    public RPCClient() {
        authenticator = new Authenticator();
        initializeGUI();
    }

    private void initializeGUI() {
        SwingUtilities.invokeLater(() -> {
            ClientGUI clientGUI = new ClientGUI(authenticator);
            clientGUI.setVisible(true);
        });
    }

    public static void main(String[] args) {
        new RPCClient();
    }
}