package com.rpcapp.server;

import com.rpcapp.common.RPCInterface;
import com.rpcapp.server.service.PasswordService;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RPCServer {
    private static final int PORT = 1099;

    public static void main(String[] args) {
        try {
            PasswordService passwordService = new PasswordService();
            Registry registry = LocateRegistry.createRegistry(PORT);
            registry.rebind("PasswordService", passwordService);
            System.out.println("RPC Server is running on port " + PORT);

            // Keep the server running
            while (true) {
                // Accept incoming connections
                Socket socket = new ServerSocket(PORT).accept();
                System.out.println("Client connected: " + socket.getInetAddress());
                // Handle client requests in a separate thread or method
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}