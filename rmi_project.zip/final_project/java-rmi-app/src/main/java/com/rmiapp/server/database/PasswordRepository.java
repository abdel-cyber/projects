package com.rpcapp.server.database;

import com.rpcapp.common.model.Password;
import java.util.HashMap;
import java.util.Map;

public class PasswordRepository {
    private Map<String, Password> passwordStore;

    public PasswordRepository() {
        this.passwordStore = new HashMap<>();
    }

    public void savePassword(Password password) {
        passwordStore.put(password.getUsername(), password);
    }

    public Password getPassword(String username) {
        return passwordStore.get(username);
    }

    public boolean passwordExists(String username) {
        return passwordStore.containsKey(username);
    }

    public void deletePassword(String username) {
        passwordStore.remove(username);
    }
}