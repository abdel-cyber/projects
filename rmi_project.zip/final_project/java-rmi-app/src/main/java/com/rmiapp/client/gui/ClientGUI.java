package com.rmiapp.client.gui;

import com.rmiapp.common.RMIInterface;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.rmi.RemoteException;
import java.util.Map;

public class ClientGUI extends JFrame {
    private RMIInterface rmiService;
    private String currentUser = null;
    private JTextField usernameField, passwordField, accountField, accountPasswordField;
    private JButton loginButton, saveButton, getButton, deleteButton, logoutButton;
    private JTextArea resultArea;
    private JPanel loginPanel, operationPanel;
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JLabel statusLabel;
    
    public ClientGUI(RMIInterface service) {
        this.rmiService = service;
        setTitle("Password Manager - RMI Client");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        initUI();
    }
    
    private void initUI() {
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        // Login Panel
        loginPanel = new JPanel();
        loginPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0;
        loginPanel.add(new JLabel("Username:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 0;
        usernameField = new JTextField(20);
        loginPanel.add(usernameField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        loginPanel.add(new JLabel("Password:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 1;
        passwordField = new JPasswordField(20);
        loginPanel.add(passwordField, gbc);
        
        gbc.gridx = 1; gbc.gridy = 2;
        loginButton = new JButton("Login");
        loginPanel.add(loginButton, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        statusLabel = new JLabel("Enter credentials to login or create a new account");
        statusLabel.setForeground(Color.BLUE);
        loginPanel.add(statusLabel, gbc);
        
        // Operations Panel
        operationPanel = new JPanel(new BorderLayout());
        
        JPanel inputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
        
        c.gridx = 0; c.gridy = 0;
        inputPanel.add(new JLabel("Account Name:"), c);
        
        c.gridx = 1; c.gridy = 0;
        accountField = new JTextField(15);
        inputPanel.add(accountField, c);
        
        c.gridx = 0; c.gridy = 1;
        inputPanel.add(new JLabel("Password:"), c);
        
        c.gridx = 1; c.gridy = 1;
        accountPasswordField = new JTextField(15);
        inputPanel.add(accountPasswordField, c);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        saveButton = new JButton("Save Password");
        getButton = new JButton("Get Password");
        deleteButton = new JButton("Delete Password");
        logoutButton = new JButton("Logout");
        
        buttonPanel.add(saveButton);
        buttonPanel.add(getButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(logoutButton);
        
        resultArea = new JTextArea(10, 40);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        
        operationPanel.add(inputPanel, BorderLayout.NORTH);
        operationPanel.add(buttonPanel, BorderLayout.CENTER);
        operationPanel.add(scrollPane, BorderLayout.SOUTH);
        
        mainPanel.add(loginPanel, "login");
        mainPanel.add(operationPanel, "operation");
        
        add(mainPanel);
        
        // Action listeners
        loginButton.addActionListener(this::login);
        saveButton.addActionListener(this::savePassword);
        getButton.addActionListener(this::getPassword);
        deleteButton.addActionListener(this::deletePassword);
        logoutButton.addActionListener(this::logout);
        
        cardLayout.show(mainPanel, "login");
    }
    
    private void login(ActionEvent e) {
        String username = usernameField.getText();
        String password = passwordField.getText();
        
        if (username.isEmpty() || password.isEmpty()) {
            showError("Username and password cannot be empty");
            return;
        }
        
        try {
            setStatusMessage("Authenticating...");
            if (rmiService.authenticate(username, password)) {
                currentUser = username;
                cardLayout.show(mainPanel, "operation");
                updateAccountList();
                setTitle("Password Manager - Connected as: " + username);
            } else {
                showError("Authentication failed");
            }
        } catch (RemoteException ex) {
            handleRemoteException("Login error", ex);
        }
    }
    
    private void savePassword(ActionEvent e) {
        if (currentUser == null) return;
        
        String account = accountField.getText();
        String password = accountPasswordField.getText();
        
        if (account.isEmpty() || password.isEmpty()) {
            showError("Account name and password cannot be empty");
            return;
        }
        
        try {
            setStatusMessage("Saving password...");
            if (rmiService.savePassword(account, password, currentUser)) {
                JOptionPane.showMessageDialog(this, "Password saved successfully", 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                updateAccountList();
            } else {
                showError("Failed to save password - session may have expired");
            }
        } catch (RemoteException ex) {
            handleRemoteException("Save error", ex);
        }
    }
    
    private void getPassword(ActionEvent e) {
        if (currentUser == null) return;
        
        String account = accountField.getText();
        
        if (account.isEmpty()) {
            showError("Please enter an account name");
            return;
        }
        
        try {
            setStatusMessage("Retrieving password...");
            String password = rmiService.getPassword(account, currentUser);
            if (password != null) {
                accountPasswordField.setText(password);
                setStatusMessage("Password retrieved successfully");
            } else {
                showError("No password found for this account or session expired");
            }
        } catch (RemoteException ex) {
            handleRemoteException("Retrieval error", ex);
        }
    }
    
    private void deletePassword(ActionEvent e) {
        if (currentUser == null) return;
        
        String account = accountField.getText();
        
        if (account.isEmpty()) {
            showError("Please enter an account name");
            return;
        }
        
        try {
            setStatusMessage("Deleting password...");
            if (rmiService.deletePassword(account, currentUser)) {
                JOptionPane.showMessageDialog(this, "Password deleted successfully", 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                accountPasswordField.setText("");
                updateAccountList();
            } else {
                showError("Failed to delete password - not found or session expired");
            }
        } catch (RemoteException ex) {
            handleRemoteException("Delete error", ex);
        }
    }
    
    private void logout(ActionEvent e) {
        currentUser = null;
        cardLayout.show(mainPanel, "login");
        usernameField.setText("");
        passwordField.setText("");
        accountField.setText("");
        accountPasswordField.setText("");
        resultArea.setText("");
        setTitle("Password Manager - RMI Client");
        setStatusMessage("Logged out successfully");
    }
    
    private void updateAccountList() {
        try {
            setStatusMessage("Retrieving accounts...");
            Map<String, String> accounts = rmiService.getAllAccounts(currentUser);
            resultArea.setText("Your saved accounts:\n");
            
            if (accounts.isEmpty()) {
                resultArea.append("No accounts found.\n");
            } else {
                for (String account : accounts.keySet()) {
                    resultArea.append("• " + account + "\n");
                }
            }
            setStatusMessage("Ready");
        } catch (RemoteException ex) {
            handleRemoteException("Error loading accounts", ex);
            resultArea.setText("Error loading accounts: Connection to server lost.");
        }
    }
    
    private void setStatusMessage(String message) {
        statusLabel.setText(message);
        statusLabel.setForeground(Color.BLUE);
    }
    
    private void showError(String message) {
        statusLabel.setText("Error: " + message);
        statusLabel.setForeground(Color.RED);
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void handleRemoteException(String context, RemoteException ex) {
        String message = context + ": " + ex.getMessage();
        System.err.println(message);
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, 
                "Connection error: " + ex.getMessage() + "\nPlease check if server is running.", 
                "Remote Error", JOptionPane.ERROR_MESSAGE);
    }
}
