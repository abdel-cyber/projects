package com.rpcapp.client.security;

import java.util.HashMap;
import java.util.Map;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordManager {
    private Map<String, String> passwordStore;

    public PasswordManager() {
        passwordStore = new HashMap<>();
    }

    public void storePassword(String username, String password) {
        String hashedPassword = hashPassword(password);
        passwordStore.put(username, hashedPassword);
    }

    public String retrievePassword(String username) {
        return passwordStore.get(username);
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
}