package com.rpcapp.common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

public interface RPCInterface extends Remote {
    boolean authenticate(String username, String password) throws RemoteException;
    boolean savePassword(String account, String password, String username) throws RemoteException;
    String getPassword(String account, String username) throws RemoteException;
    boolean deletePassword(String account, String username) throws RemoteException;
    Map<String, String> getAllAccounts(String username) throws RemoteException;
    
    // Méthode pour tester la connexion avec timeout
    boolean ping() throws RemoteException;
}
