package com.rmiapp.server.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public class ServerGUI extends JFrame {
    private JTextArea logArea;
    private JTable userTable;
    private DefaultTableModel userTableModel;
    private JTable activityTable;
    private DefaultTableModel activityTableModel;
    private JLabel statusLabel;
    private JLabel connectionCountLabel;
    private JButton clearLogButton;
    private JButton shutdownButton;
    private int connectionCount = 0;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

    public ServerGUI() {
        setTitle("RMI Password Manager Server");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int result = JOptionPane.showConfirmDialog(
                    ServerGUI.this,
                    "Are you sure you want to shutdown the server?",
                    "Confirm Shutdown",
                    JOptionPane.YES_NO_OPTION);
                
                if (result == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
        
        initUI();
    }
    
    private void initUI() {
        // Main panel using border layout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Server status panel (top)
        JPanel statusPanel = createStatusPanel();
        mainPanel.add(statusPanel, BorderLayout.NORTH);
        
        // Center panel with split between tables and logs
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setDividerLocation(300);
        
        // Tables panel with users and activities
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // User table
        userTableModel = new DefaultTableModel(
            new Object[][] {},
            new String[] {"Username", "Last Login", "Password Count", "Status"}
        );
        userTable = new JTable(userTableModel);
        JScrollPane userScrollPane = new JScrollPane(userTable);
        tabbedPane.addTab("Users", null, userScrollPane, "View connected users");
        
        // Activity table
        activityTableModel = new DefaultTableModel(
            new Object[][] {},
            new String[] {"Time", "User", "Action", "Details"}
        );
        activityTable = new JTable(activityTableModel);
        JScrollPane activityScrollPane = new JScrollPane(activityTable);
        tabbedPane.addTab("Activity", null, activityScrollPane, "View user activity");
        
        splitPane.setTopComponent(tabbedPane);
        
        // Log panel
        JPanel logPanel = new JPanel(new BorderLayout(5, 5));
        logPanel.setBorder(BorderFactory.createTitledBorder("Server Logs"));
        
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        logArea.setBackground(new Color(240, 240, 240));
        JScrollPane logScrollPane = new JScrollPane(logArea);
        logPanel.add(logScrollPane, BorderLayout.CENTER);
        
        // Log control buttons
        JPanel logControlPanel = new JPanel();
        clearLogButton = new JButton("Clear Logs");
        clearLogButton.addActionListener(e -> logArea.setText(""));
        logControlPanel.add(clearLogButton);
        logPanel.add(logControlPanel, BorderLayout.SOUTH);
        
        splitPane.setBottomComponent(logPanel);
        
        mainPanel.add(splitPane, BorderLayout.CENTER);
        
        add(mainPanel);
        
        log("Server initialized");
        log("Waiting for client connections...");
    }
    
    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEtchedBorder(),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        JPanel infoPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        
        JPanel statusLinePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel statusTextLabel = new JLabel("Server Status: ");
        statusTextLabel.setFont(new Font("Dialog", Font.BOLD, 14));
        statusLabel = new JLabel("RUNNING");
        statusLabel.setForeground(new Color(0, 150, 0));
        statusLabel.setFont(new Font("Dialog", Font.BOLD, 14));
        
        statusLinePanel.add(statusTextLabel);
        statusLinePanel.add(statusLabel);
        
        JPanel connectionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel connectionsTextLabel = new JLabel("Active Connections: ");
        connectionsTextLabel.setFont(new Font("Dialog", Font.BOLD, 14));
        connectionCountLabel = new JLabel("0");
        connectionCountLabel.setFont(new Font("Dialog", Font.BOLD, 14));
        
        connectionsPanel.add(connectionsTextLabel);
        connectionsPanel.add(connectionCountLabel);
        
        infoPanel.add(statusLinePanel);
        infoPanel.add(connectionsPanel);
        
        panel.add(infoPanel, BorderLayout.WEST);
        
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        shutdownButton = new JButton("Shutdown Server");
        shutdownButton.setBackground(new Color(220, 80, 80));
        shutdownButton.setForeground(Color.WHITE);
        shutdownButton.addActionListener(e -> {
            int result = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to shutdown the server?",
                "Confirm Shutdown",
                JOptionPane.YES_NO_OPTION);
            
            if (result == JOptionPane.YES_OPTION) {
                log("Server shutdown initiated by admin");
                setStatus("SHUTTING DOWN", new Color(200, 0, 0));
                // Give UI time to update before exit
                Timer timer = new Timer(1000, event -> System.exit(0));
                timer.setRepeats(false);
                timer.start();
            }
        });
        controlPanel.add(shutdownButton);
        
        panel.add(controlPanel, BorderLayout.EAST);
        
        return panel;
    }
    
    public void log(String message) {
        SwingUtilities.invokeLater(() -> {
            String timestamp = timeFormat.format(new Date());
            logArea.append("[" + timestamp + "] " + message + "\n");
            // Auto scroll to bottom
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }
    
    public void addUserActivity(String username, String action, String details) {
        SwingUtilities.invokeLater(() -> {
            Vector<String> row = new Vector<>();
            row.add(timeFormat.format(new Date()));
            row.add(username);
            row.add(action);
            row.add(details);
            activityTableModel.addRow(row);
            
            // Log the activity as well
            log(username + " " + action + ": " + details);
        });
    }
    
    public void updateUserInfo(String username, String lastLogin, int passwordCount, boolean active) {
        SwingUtilities.invokeLater(() -> {
            // Check if user already exists in the table
            boolean found = false;
            for (int i = 0; i < userTableModel.getRowCount(); i++) {
                if (userTableModel.getValueAt(i, 0).equals(username)) {
                    userTableModel.setValueAt(lastLogin, i, 1);
                    userTableModel.setValueAt(passwordCount, i, 2);
                    userTableModel.setValueAt(active ? "Active" : "Inactive", i, 3);
                    found = true;
                    break;
                }
            }
            
            // Add new user if not found
            if (!found) {
                Vector<Object> row = new Vector<>();
                row.add(username);
                row.add(lastLogin);
                row.add(passwordCount);
                row.add(active ? "Active" : "Inactive");
                userTableModel.addRow(row);
            }
        });
    }
    
    public void incrementConnections() {
        SwingUtilities.invokeLater(() -> {
            connectionCount++;
            connectionCountLabel.setText(String.valueOf(connectionCount));
        });
    }
    
    public void decrementConnections() {
        SwingUtilities.invokeLater(() -> {
            if (connectionCount > 0) {
                connectionCount--;
                connectionCountLabel.setText(String.valueOf(connectionCount));
            }
        });
    }
    
    public void setStatus(String status, Color color) {
        SwingUtilities.invokeLater(() -> {
            statusLabel.setText(status);
            statusLabel.setForeground(color);
        });
    }
}
