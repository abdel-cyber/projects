import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PasswordManagerGUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextArea passwordDisplayArea;
    private JButton saveButton;
    private JButton retrieveButton;

    public PasswordManagerGUI() {
        setTitle("Password Manager");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2));

        inputPanel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        inputPanel.add(usernameField);

        inputPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        inputPanel.add(passwordField);

        saveButton = new JButton("Save Password");
        retrieveButton = new JButton("Retrieve Password");

        inputPanel.add(saveButton);
        inputPanel.add(retrieveButton);

        add(inputPanel, BorderLayout.NORTH);

        passwordDisplayArea = new JTextArea();
        passwordDisplayArea.setEditable(false);
        add(new JScrollPane(passwordDisplayArea), BorderLayout.CENTER);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                savePassword();
            }
        });

        retrieveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                retrievePassword();
            }
        });
    }

    private void savePassword() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        // Logic to save the password securely
        passwordDisplayArea.append("Saved: " + username + "\n");
    }

    private void retrievePassword() {
        String username = usernameField.getText();
        // Logic to retrieve the password securely
        passwordDisplayArea.append("Retrieved: " + username + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PasswordManagerGUI gui = new PasswordManagerGUI();
            gui.setVisible(true);
        });
    }
}