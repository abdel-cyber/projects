package com.rmiapp.client.gui;

import com.rmiapp.common.RMIInterface;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.rmi.RemoteException;
import java.util.Map;

public class ModernClientGUI extends JFrame {
    private RMIInterface rmiService;
    private String currentUser = null;
    
    // UI Components
    private JTextField usernameField, accountField;
    private JPasswordField passwordField, accountPasswordField;
    private JCheckBox showPasswordCheckbox;
    private JButton loginButton, saveButton, getButton, deleteButton, logoutButton, refreshButton;
    private JTextArea resultArea;
    private JPanel loginPanel, operationPanel;
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JPanel contentPanel;
    private JLabel statusLabel;
    private JToggleButton themeToggle;
    private JProgressBar progressBar;
    private DefaultListModel<String> accountListModel;
    private JList<String> accountList;
    private Timer activityTimer;
    private boolean darkTheme = false;
    
    // Colors
    private Color primaryColor = new Color(66, 133, 244);
    private Color accentColor = new Color(52, 168, 83);
    private Color lightBgColor = Color.WHITE;
    private Color darkBgColor = new Color(43, 43, 43);
    
    public ModernClientGUI(RMIInterface service) {
        this.rmiService = service;
        setTitle("Secure Password Manager");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        initUI();
        applyTheme();
        
        // Timer for network activity simulation
        activityTimer = new Timer(300, e -> progressBar.setValue(0));
        activityTimer.setRepeats(false);
    }
    
    private void initUI() {
        mainPanel = new JPanel(new BorderLayout());
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        
        // Create header
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create footer with status
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        // Login panel with animation
        loginPanel = createLoginPanel();
        contentPanel.add(loginPanel, "login");
        
        // Operation panel (visible after login)
        operationPanel = createOperationPanel();
        contentPanel.add(operationPanel, "operation");
        
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        add(mainPanel);
        
        cardLayout.show(contentPanel, "login");
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        // Use Unicode lock symbol as icon
        JLabel iconLabel = new JLabel("🔒");
        iconLabel.setFont(new Font("Dialog", Font.BOLD, 24));
        JLabel titleLabel = new JLabel("Secure Password Manager");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        titlePanel.add(iconLabel);
        titlePanel.add(titleLabel);
        
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        themeToggle = new JToggleButton("Dark Mode");
        themeToggle.addActionListener(e -> {
            darkTheme = themeToggle.isSelected();
            applyTheme();
        });
        
        controlPanel.add(themeToggle);
        
        panel.add(titlePanel, BorderLayout.WEST);
        panel.add(controlPanel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        
        statusLabel = new JLabel("Ready");
        panel.add(statusLabel, BorderLayout.WEST);
        
        progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(150, 20));
        progressBar.setStringPainted(true);
        panel.add(progressBar, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createLoginPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(80, 40, 80, 40));
        
        // Logo and welcome message
        JLabel logoLabel = new JLabel("🔐");  // Use Unicode as placeholder
        logoLabel.setFont(new Font("Dialog", Font.BOLD, 64));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));
        
        JLabel welcomeLabel = new JLabel("Welcome to Password Manager");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Please login or create a new account");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        welcomePanel.add(Box.createVerticalStrut(20));
        welcomePanel.add(logoLabel);
        welcomePanel.add(Box.createVerticalStrut(20));
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createVerticalStrut(10));
        welcomePanel.add(subtitleLabel);
        welcomePanel.add(Box.createVerticalStrut(40));
        
        // Create login form in a card
        JPanel formCard = new JPanel();
        formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));
        formCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        formCard.setMaximumSize(new Dimension(400, 300));
        formCard.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JPanel usernamePanel = new JPanel();
        usernamePanel.setLayout(new BoxLayout(usernamePanel, BoxLayout.Y_AXIS));
        JLabel usernameLabel = new JLabel("Username");
        usernameField = new JTextField(20);
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        usernamePanel.add(usernameLabel);
        usernamePanel.add(Box.createVerticalStrut(5));
        usernamePanel.add(usernameField);
        
        JPanel passwordPanel = new JPanel();
        passwordPanel.setLayout(new BoxLayout(passwordPanel, BoxLayout.Y_AXIS));
        JLabel passwordLabel = new JLabel("Password");
        passwordField = new JPasswordField(20);
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        passwordPanel.add(passwordLabel);
        passwordPanel.add(Box.createVerticalStrut(5));
        passwordPanel.add(passwordField);
        
        loginButton = new JButton("Login / Create Account");
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.setBackground(primaryColor);
        loginButton.setForeground(Color.WHITE);
        loginButton.addActionListener(this::login);
        
        // Add enter key listener to password field
        passwordField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    login(new ActionEvent(loginButton, ActionEvent.ACTION_PERFORMED, null));
                }
            }
        });
        
        formCard.add(usernamePanel);
        formCard.add(Box.createVerticalStrut(15));
        formCard.add(passwordPanel);
        formCard.add(Box.createVerticalStrut(25));
        formCard.add(loginButton);
        
        panel.add(welcomePanel);
        panel.add(Box.createVerticalStrut(20));
        panel.add(formCard);
        
        return panel;
    }
    
    private JPanel createOperationPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Left panel - account list
        JPanel leftPanel = new JPanel(new BorderLayout(5, 5));
        leftPanel.setBorder(BorderFactory.createTitledBorder("Your Accounts"));
        
        accountListModel = new DefaultListModel<>();
        accountList = new JList<>(accountListModel);
        accountList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        accountList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && accountList.getSelectedIndex() != -1) {
                String selectedAccount = accountList.getSelectedValue();
                accountField.setText(selectedAccount);
                getPassword(null);
            }
        });
        JScrollPane accountScrollPane = new JScrollPane(accountList);
        
        JPanel listControlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> updateAccountList());
        listControlPanel.add(refreshButton);
        
        leftPanel.add(accountScrollPane, BorderLayout.CENTER);
        leftPanel.add(listControlPanel, BorderLayout.SOUTH);
        
        // Right panel - operations
        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        
        // Account management panel
        JPanel accountPanel = new JPanel(new BorderLayout(10, 10));
        accountPanel.setBorder(BorderFactory.createTitledBorder("Manage Passwords"));
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Account/Site:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        accountField = new JTextField(20);
        formPanel.add(accountField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        formPanel.add(new JLabel("Password:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        accountPasswordField = new JPasswordField(20);
        formPanel.add(accountPasswordField, gbc);
        
        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 0;
        showPasswordCheckbox = new JCheckBox("Show Password");
        showPasswordCheckbox.addActionListener(e -> {
            if (showPasswordCheckbox.isSelected()) {
                accountPasswordField.setEchoChar((char) 0); // Show password
            } else {
                accountPasswordField.setEchoChar('●'); // Hide password
            }
        });
        formPanel.add(showPasswordCheckbox, gbc);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        
        saveButton = new JButton("Save");
        saveButton.setBackground(accentColor);
        saveButton.setForeground(Color.WHITE);
        saveButton.addActionListener(this::savePassword);
        
        getButton = new JButton("Get Password");
        getButton.addActionListener(this::getPassword);
        
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this::deletePassword);
        
        logoutButton = new JButton("Logout");
        logoutButton.addActionListener(this::logout);
        
        buttonPanel.add(saveButton);
        buttonPanel.add(getButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(logoutButton);
        
        accountPanel.add(formPanel, BorderLayout.CENTER);
        accountPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Result panel
        JPanel resultPanel = new JPanel(new BorderLayout());
        resultPanel.setBorder(BorderFactory.createTitledBorder("Notes"));
        
        resultArea = new JTextArea(5, 30);
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        JScrollPane resultScroll = new JScrollPane(resultArea);
        resultPanel.add(resultScroll, BorderLayout.CENTER);
        
        // Add all components to right panel
        rightPanel.add(accountPanel, BorderLayout.NORTH);
        rightPanel.add(resultPanel, BorderLayout.CENTER);
        
        // Add panels to split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(250);
        
        panel.add(splitPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void login(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            showError("Username and password cannot be empty");
            return;
        }
        
        try {
            setStatus("Authenticating...");
            simulateNetworkActivity();
            
            if (rmiService.authenticate(username, password)) {
                currentUser = username;
                cardLayout.show(contentPanel, "operation");
                updateAccountList();
                setTitle("Secure Password Manager - " + username);
                setStatus("Logged in successfully");
            } else {
                showError("Authentication failed");
            }
        } catch (RemoteException ex) {
            handleRemoteException("Login error", ex);
        }
    }
    
    private void savePassword(ActionEvent e) {
        if (currentUser == null) return;
        
        String account = accountField.getText().trim();
        String password = new String(accountPasswordField.getPassword());
        
        if (account.isEmpty() || password.isEmpty()) {
            showError("Account name and password cannot be empty");
            return;
        }
        
        try {
            setStatus("Saving password...");
            simulateNetworkActivity();
            
            if (rmiService.savePassword(account, password, currentUser)) {
                setStatus("Password saved successfully");
                updateAccountList();
                
                // Flash success message
                resultArea.setText("Password for '" + account + "' has been saved successfully.");
            } else {
                showError("Failed to save password - session may have expired");
            }
        } catch (RemoteException ex) {
            handleRemoteException("Save error", ex);
        }
    }
    
    private void getPassword(ActionEvent e) {
        if (currentUser == null) return;
        
        String account = accountField.getText().trim();
        
        if (account.isEmpty()) {
            showError("Please enter or select an account name");
            return;
        }
        
        try {
            setStatus("Retrieving password...");
            simulateNetworkActivity();
            
            // Récupération du mot de passe depuis le serveur
            String password = rmiService.getPassword(account, currentUser);
            
            // Debug pour voir ce qui est reçu
            System.out.println("CLIENT DEBUG - Received from server for " + account + ": " + 
                    (password != null ? "[" + password + "]" : "null"));
            
            if (password != null) {
                // IMPORTANT: Affichage du mot de passe en clair
                accountPasswordField.setText(password);
                
                // Automatiquement afficher le mot de passe en clair lors de la récupération
                accountPasswordField.setEchoChar((char) 0);
                showPasswordCheckbox.setSelected(true);
                
                resultArea.setText("Password for '" + account + "' retrieved successfully.\nThe password is displayed in clear text.");
                setStatus("Password retrieved successfully");
            } else {
                showError("No password found for this account or session expired");
                accountPasswordField.setText("");
            }
        } catch (RemoteException ex) {
            handleRemoteException("Retrieval error", ex);
        }
    }
    
    private void deletePassword(ActionEvent e) {
        if (currentUser == null) return;
        
        String account = accountField.getText().trim();
        
        if (account.isEmpty()) {
            showError("Please enter or select an account name");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete the password for '" + account + "'?",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
        
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        
        try {
            setStatus("Deleting password...");
            simulateNetworkActivity();
            
            if (rmiService.deletePassword(account, currentUser)) {
                setStatus("Password deleted successfully");
                accountPasswordField.setText("");
                updateAccountList();
                resultArea.setText("Password for '" + account + "' has been deleted.");
            } else {
                showError("Failed to delete password - not found or session expired");
            }
        } catch (RemoteException ex) {
            handleRemoteException("Delete error", ex);
        }
    }
    
    private void logout(ActionEvent e) {
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION
        );
        
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        
        currentUser = null;
        cardLayout.show(contentPanel, "login");
        usernameField.setText("");
        passwordField.setText("");
        accountField.setText("");
        accountPasswordField.setText("");
        resultArea.setText("");
        accountListModel.clear();
        setTitle("Secure Password Manager");
        setStatus("Logged out successfully");
    }
    
    private void updateAccountList() {
        try {
            setStatus("Retrieving accounts...");
            simulateNetworkActivity();
            
            Map<String, String> accounts = rmiService.getAllAccounts(currentUser);
            
            accountListModel.clear();
            if (accounts.isEmpty()) {
                resultArea.setText("You don't have any saved passwords yet.\n" +
                    "Enter an account name and password, then click 'Save'.");
            } else {
                for (String account : accounts.keySet()) {
                    accountListModel.addElement(account);
                }
                resultArea.setText("Select an account from the list to view its password.");
            }
            
            setStatus("Ready");
        } catch (RemoteException ex) {
            handleRemoteException("Error loading accounts", ex);
            resultArea.setText("Error loading accounts: Connection to server lost.");
        }
    }
    
    private void simulateNetworkActivity() {
        progressBar.setValue(75);
        activityTimer.restart();
    }
    
    private void setStatus(String message) {
        statusLabel.setText(message);
        statusLabel.setForeground(darkTheme ? Color.LIGHT_GRAY : Color.DARK_GRAY);
    }
    
    private void showError(String message) {
        statusLabel.setText("Error: " + message);
        statusLabel.setForeground(Color.RED);
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void handleRemoteException(String context, RemoteException ex) {
        String message = context + ": " + ex.getMessage();
        System.err.println(message);
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, 
                "Connection error: " + ex.getMessage() + "\nPlease check if server is running.", 
                "Remote Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void applyTheme() {
        if (darkTheme) {
            mainPanel.setBackground(darkBgColor);
            loginPanel.setBackground(darkBgColor);
            operationPanel.setBackground(darkBgColor);
            
            Color darkTextColor = new Color(220, 220, 220);
            
            // Update text colors recursively
            updateComponentColors(mainPanel, darkBgColor, darkTextColor);
            
            themeToggle.setText("Light Mode");
        } else {
            mainPanel.setBackground(lightBgColor);
            loginPanel.setBackground(lightBgColor);
            operationPanel.setBackground(lightBgColor);
            
            Color lightTextColor = new Color(33, 33, 33);
            
            // Update text colors recursively
            updateComponentColors(mainPanel, lightBgColor, lightTextColor);
            
            themeToggle.setText("Dark Mode");
        }
        
        SwingUtilities.updateComponentTreeUI(this);
    }
    
    private void updateComponentColors(Container container, Color bg, Color fg) {
        container.setBackground(bg);
        container.setForeground(fg);
        
        for (Component comp : container.getComponents()) {
            if (comp instanceof JButton) {
                // Leave buttons with their custom colors
                if (!comp.equals(loginButton) && !comp.equals(saveButton)) {
                    comp.setBackground(bg);
                    comp.setForeground(fg);
                }
            } else {
                comp.setBackground(bg);
                comp.setForeground(fg);
            }
            
            if (comp instanceof Container) {
                updateComponentColors((Container) comp, bg, fg);
            }
        }
    }
}
