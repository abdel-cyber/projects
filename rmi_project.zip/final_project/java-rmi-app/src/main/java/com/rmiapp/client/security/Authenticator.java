package com.rpcapp.client.security;

import java.util.HashMap;
import java.util.Map;

public class Authenticator {
    private Map<String, String> userCredentials;

    public Authenticator() {
        userCredentials = new HashMap<>();
    }

    public void registerUser(String username, String password) {
        String hashedPassword = hashPassword(password);
        userCredentials.put(username, hashedPassword);
    }

    public boolean authenticateUser(String username, String password) {
        String hashedPassword = userCredentials.get(username);
        return hashedPassword != null && hashedPassword.equals(hashPassword(password));
    }

    private String hashPassword(String password) {
        // Implement a secure hashing algorithm here (e.g., BCrypt)
        return Integer.toString(password.hashCode()); // Placeholder for demonstration
    }
}