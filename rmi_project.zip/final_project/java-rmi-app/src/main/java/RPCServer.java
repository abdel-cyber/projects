package com.rpcapp.server;

import com.rpcapp.common.RPCInterface;
import com.rpcapp.server.service.PasswordService;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RPCServer {
    private static final int PORT = 1099;

    public static void main(String[] args) {
        try {
            PasswordService passwordService = new PasswordService();
            RPCInterface stub = (RPCInterface) java.rmi.server.UnicastRemoteObject.exportObject(passwordService, 0);

            Registry registry = LocateRegistry.createRegistry(PORT);
            registry.rebind("PasswordService", stub);

            System.out.println("RPC Server is running on port " + PORT);
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}