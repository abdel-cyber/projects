import com.rmiapp.client.gui.ModernClientGUI;
import com.rmiapp.common.RMIInterface;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;

public class RMIClient {
    public static void main(String[] args) {
        try {
            String host = "localhost";
            if (args.length > 0) {
                host = args[0];
            }
            
            System.out.println("Connecting to RMI server at " + host + "...");
            
            Registry registry = LocateRegistry.getRegistry(host, 1099);
            RMIInterface passwordService = (RMIInterface) registry.lookup("PasswordService");
            
            // Test connection
            if (passwordService.ping()) {
                System.out.println("Successfully connected to server");
            }
            
            // Launch GUI
            SwingUtilities.invokeLater(() -> {
                ModernClientGUI gui = new ModernClientGUI(passwordService);
                gui.setVisible(true);
            });
            
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
            
            JOptionPane.showMessageDialog(null, 
                "Error connecting to server: " + e.getMessage() + "\n" +
                "Please make sure the server is running.",
                "Connection Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
}
