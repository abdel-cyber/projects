import com.rmiapp.common.RMIInterface;
import com.rmiapp.server.gui.ServerGUI;
import com.rmiapp.server.service.PasswordService;

import javax.swing.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RMIServer {
    private static final int PORT = 1099;
    private static ServerGUI gui;

    public static void main(String[] args) {
        try {
            // Create and show GUI
            SwingUtilities.invokeLater(() -> {
                gui = new ServerGUI();
                gui.setVisible(true);
            });
            
            // Give the GUI time to initialize
            Thread.sleep(500);
            
            if (gui != null) {
                gui.log("Initializing Password Manager RMI Server...");
            }
            
            // Create the password service with reference to GUI
            PasswordService passwordService = new PasswordService(gui);
            RMIInterface stub = (RMIInterface) java.rmi.server.UnicastRemoteObject.exportObject(passwordService, 0);

            Registry registry = LocateRegistry.createRegistry(PORT);
            registry.rebind("PasswordService", stub);

            if (gui != null) {
                gui.log("RMI Server is running on port " + PORT);
                gui.log("Waiting for client connections...");
            } else {
                System.out.println("RMI Server is running on port " + PORT);
            }
            
        } catch (Exception e) {
            if (gui != null) {
                gui.log("Server error: " + e.toString());
            }
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
    
    public static void logActivity(String username, String action, String details) {
        if (gui != null) {
            gui.addUserActivity(username, action, details);
        }
    }
}
