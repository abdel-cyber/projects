package com.rpcapp.client;

import com.rpcapp.client.gui.ClientGUI;

public class RPCClient {
    public static void main(String[] args) {
        try {
            System.out.println("Starting Password Manager Client...");
            ClientGUI gui = new ClientGUI();
            gui.setVisible(true);
            System.out.println("Client GUI started successfully");
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
